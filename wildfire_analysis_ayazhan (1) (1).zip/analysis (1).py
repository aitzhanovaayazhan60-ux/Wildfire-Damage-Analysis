#!/usr/bin/env python
# coding: utf-8

# # Statistical Data Analysis – Variant 03: Forest Wildfires
# 
# Unit of observation: one wildfire event. Target: `damage_million_usd` (column 12). First predictor: `wind_kmh` (column 5). Clusters: `site_id` (80 sites). **All data are synthetic.**
# 
# How to run: put `03_wildfires.csv` in the folder `data` (or next to this notebook), install the packages from `requirements.txt` and press *Run All* (or run `python analysis.py` in the VS Code terminal). Results are saved in the folders `outputs` and `figures`. The raw data are never changed.

# In[1]:


import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from IPython.display import display


# In[2]:


n_boot = 2000
seed = 42

os.makedirs("outputs", exist_ok=True)
os.makedirs("figures", exist_ok=True)


# ## 0. Helper functions for the cluster bootstrap
# 
# Rows from the same site are not independent, so for confidence intervals I resample **sites** (not rows) with replacement. All rows of a chosen site are kept, and a site that is chosen twice is used twice. All 80 sites are resampled; if a chosen site has no rows in a subset (for example in one month), it adds no rows to that subset.

# In[3]:


def resample_sites(site_tables, rng):
    sites = all_sites
    chosen = rng.choice(sites, size=len(sites), replace=True)
    samples = [site_tables[s] for s in chosen if s in site_tables and not site_tables[s].empty]
    if not samples:
        return pd.DataFrame(columns=next(iter(site_tables.values())).columns)
    return pd.concat(samples, ignore_index=True)


# In[4]:


def cluster_bootstrap_mean_ci(data, value_col):
    data = data[[value_col, "site_id"]].dropna()
    sites = all_sites
    values_by_site = {
        s: data.loc[data["site_id"] == s, value_col].to_numpy()
        for s in sites
    }

    rng = np.random.default_rng(seed)
    means = []
    for _ in range(n_boot):
        chosen = rng.choice(sites, size=len(sites), replace=True)
        chunks = [values_by_site[s] for s in chosen if len(values_by_site[s]) > 0]
        sample = np.concatenate(chunks) if chunks else np.array([])
        means.append(sample.mean() if len(sample) else np.nan)

    return np.nanpercentile(means, [2.5, 97.5])


# ## 1. Data checks and cleaning

# In[5]:


data_file = "data/03_wildfires.csv"
if not os.path.exists(data_file):
    data_file = "03_wildfires.csv"

df_raw = pd.read_csv(data_file)
all_sites = df_raw["site_id"].dropna().unique()
print("Shape (rows, columns):", df_raw.shape)
display(df_raw.head())


# In[6]:


# 1.2 all 30 fields: type, missing values, unique values
fields = pd.DataFrame({
    "dtype": df_raw.dtypes.astype(str),
    "n_missing": df_raw.isna().sum(),
    "pct_missing": (df_raw.isna().mean() * 100).round(2),
    "n_unique": df_raw.nunique()
})
display(fields)


# In[7]:


print("record_id unique:", df_raw["record_id"].is_unique)
print("Missing record_id:", df_raw["record_id"].isna().sum())
print("record_id has format D03-NNNNN:", df_raw["record_id"].str.match(r"^D03-\d{5}$").all())
print("Duplicate full rows:", df_raw.duplicated().sum())
print("Number of sites:", df_raw["site_id"].nunique())


# In[8]:


num_cols = df_raw.select_dtypes(include="number").columns

ranges = pd.DataFrame({
    "Min": df_raw[num_cols].min(),
    "Max": df_raw[num_cols].max(),
    "Missing": df_raw[num_cols].isna().sum()
})
display(ranges)


# In[9]:


for col in num_cols:
    n_negative = (df_raw[col] < 0).sum()
    if n_negative > 0:
        print(col, "has", n_negative, "negative values")

print("Negative check finished")
print("Humidity outside 0-100:", ((df_raw["humidity_pct"] < 0) | (df_raw["humidity_pct"] > 100)).sum())


# In[10]:


print("wind = 0:", (df_raw["wind_kmh"] == 0).sum())
print("wind = 80 (maximum):", (df_raw["wind_kmh"] == 80).sum())
print("damage = 0.1 (minimum):", (df_raw["damage_million_usd"] == 0.1).sum())
print("damage = 250 (maximum):", (df_raw["damage_million_usd"] == 250).sum())
print("Share of events with damage = 250:", round((df_raw["damage_million_usd"] == 250).mean() * 100, 1), "%")


# In[11]:


dates = pd.to_datetime(df_raw["date"], errors="coerce")
base_dates = pd.to_datetime(df_raw["baseline_date"], errors="coerce")

print("Bad dates:", dates.isna().sum(), "| bad baseline dates:", base_dates.isna().sum())
print("First date:", dates.min().date(), "| last date:", dates.max().date())
print("Baseline date after event date:", (base_dates > dates).sum())
print("Days between baseline_date and date:", (dates - base_dates).dt.days.unique())


# In[12]:


cat_cols = ["region", "category", "collection_mode", "resource_level", "quality_flag", "cohort"]

for col in cat_cols:
    print("\n" + col)
    print(df_raw[col].value_counts(dropna=False))


# In[13]:


missing_cols = df_raw.columns[df_raw.isna().any()]

missing_by_mode = df_raw[missing_cols].isna().groupby(df_raw["collection_mode"]).mean() * 100
display(missing_by_mode.round(2))
missing_by_mode.round(2).reset_index().to_csv("outputs/missing_by_collection_mode.csv", index=False)


# In[14]:


any_missing = df_raw[missing_cols].isna().any(axis=1)
print((any_missing.groupby(df_raw["collection_mode"]).mean() * 100).round(2))


# In[15]:


for col in missing_cols:
    table = pd.crosstab(df_raw["collection_mode"], df_raw[col].isna())
    chi2, p, dof, expected = stats.chi2_contingency(table)
    print(col, "p-value =", round(p, 4))


# In[16]:


display(df_raw.groupby("quality_flag")[["wind_kmh", "damage_million_usd", "area_ha", "response_hours"]].median().round(2))


# In[17]:


review = df_raw[df_raw["quality_flag"] == "Review"]
print("Review rows:", len(review))
print("Review rows with wind = 80:", (review["wind_kmh"] == 80).sum())
print("All rows with wind = 80:", (df_raw["wind_kmh"] == 80).sum())


# **What the checks show.** The data have 5,000 rows and 30 columns, `record_id` is unique and always has the format D03-NNNNN, there are no duplicate rows, 80 sites, no wrong dates and no negative or impossible values. The baseline date is exactly 365 days before the event date in every row.
# 
# Six columns have missing values (366 values, about 1% each): `temperature_c`, `response_hours`, `evacuated_people`, `vehicles`, `smoke_pm25_ug_m3` and `water_used_m3`. The missing values depend on `collection_mode` (chi-square p < 0.05 for every one of the six columns): Manual rows have a missing value more often (11.6%) than Automatic (5.3%) and Hybrid (4.4%). So the values are not missing completely at random.
# 
# Many variables have a fixed minimum and maximum. The most important one is the target: **467 events (9.3%) have damage exactly 250**, so 250 is a ceiling and not a real value. All 25 `Review` rows have wind = 80 (the maximum), but their damage is similar to the other rows (median 182.8 and 186.9).
# 
# **Cleaning decisions.**
# 1. No rows are deleted (5,000 before and after). Review rows stay and get a flag `is_review`. Later I check that the results do not change without them.
# 2. Missing values are not filled in. Filling them with the median would create fake values and hide that Manual collection loses more data. Each analysis uses the non-missing rows and reports its own n (for example `vehicles` n = 4,939). In the model, imputation is done inside the pipeline on the training rows only.
# 3. Dates are changed to datetime. No negative or impossible values were found, so nothing had to be set to missing.

# In[18]:


df = df_raw.copy()
df["date"] = pd.to_datetime(df["date"])
df["baseline_date"] = pd.to_datetime(df["baseline_date"])
df["is_review"] = df["quality_flag"] == "Review"


# In[19]:


df.to_csv("outputs/cleaned.csv", index=False)

print("Rows before cleaning:", len(df_raw), "| after cleaning:", len(df))
print("Rows removed:", len(df_raw) - len(df))

row_counts = pd.DataFrame({
    "Step": ["Raw data", "Clean data"],
    "Rows": [len(df_raw), len(df)],
    "Columns": [df_raw.shape[1], df.shape[1]],
    "Missing cells": [df_raw.isna().sum().sum(), df.isna().sum().sum()]
})
row_counts.to_csv("outputs/row_counts.csv", index=False)
print("Missing cells before:", df_raw.isna().sum().sum(), "| after:", df.isna().sum().sum())


# ## 2. Sorting and filtering (missing values are placed last)

# In[20]:


# 2.1 sort by damage (high to low), then record_id (A to Z)
sorted_damage = df.sort_values(
    by=["damage_million_usd", "record_id"],
    ascending=[False, True],
    na_position="last"
)
sorted_damage.to_csv("outputs/wildfires_sorted_by_damage.csv", index=False)
display(sorted_damage[["record_id", "region", "category", "wind_kmh", "damage_million_usd"]].head())


# In[21]:


# 2.2 sort by region (A-Z), date (old to new), wind (high to low)
sorted_region = df.sort_values(
    by=["region", "date", "wind_kmh"],
    ascending=[True, True, False],
    na_position="last"
)
sorted_region.to_csv("outputs/wildfires_sorted_by_region.csv", index=False)
display(sorted_region[["record_id", "region", "date", "wind_kmh"]].head())


# In[22]:


# 2.3 filter: categories Surface and Crown, wind above P75 of all wind values
wind_p75 = df["wind_kmh"].quantile(0.75)
selected_categories = ["Surface", "Crown"]

filtered_fires = df[df["category"].isin(selected_categories) & (df["wind_kmh"] > wind_p75)]
filtered_fires.to_csv("outputs/wildfires_filtered_categories.csv", index=False)

print("Selected categories:", selected_categories)
print("P75 of wind_kmh =", round(wind_p75, 3), "km/h; condition: wind_kmh > P75")
print("Filtered n =", len(filtered_fires))

filter_info = pd.DataFrame({
    "Item": ["Categories", "Condition", "Threshold P75 of wind_kmh (km/h)", "n rows in the filtered file"],
    "Value": [", ".join(selected_categories), "wind_kmh > P75", round(wind_p75, 3), len(filtered_fires)]
})
filter_info.to_csv("outputs/filter_info.csv", index=False)


# ## 3. Column 12: damage_million_usd

# In[23]:


# 3.1 descriptive statistics
damage = df["damage_million_usd"]

damage_stats = pd.Series({
    "n": damage.count(),
    "missing": damage.isna().sum(),
    "missing_pct": damage.isna().mean() * 100,
    "mean": damage.mean(),
    "median": damage.median(),
    "variance": damage.var(ddof=1),
    "sd": damage.std(ddof=1),
    "Q1": damage.quantile(0.25),
    "Q3": damage.quantile(0.75),
    "IQR": damage.quantile(0.75) - damage.quantile(0.25),
    "P90": damage.quantile(0.90),
    "skewness": damage.skew()
})
display(damage_stats.round(3).to_frame("Value"))


# In[24]:


# 3.2 save summary.csv with units
units = ["count", "count", "%", "million USD", "million USD", "million USD squared", "million USD",
         "million USD", "million USD", "million USD", "million USD", "no unit"]

summary = pd.DataFrame({"Statistic": damage_stats.index, "Value": damage_stats.values, "Unit": units})
summary.to_csv("outputs/summary.csv", index=False)


# In[25]:


# 3.3 histogram
plt.figure(figsize=(7, 5))
plt.hist(damage.dropna(), bins=30, edgecolor="black")
plt.title("Wildfire damage (n = " + str(damage.count()) + ", synthetic data)")
plt.xlabel("Damage (million USD)")
plt.ylabel("Number of wildfire events")
plt.savefig("figures/01_damage_histogram.png", dpi=150, bbox_inches="tight")
plt.show()


# In[26]:


# 3.4 boxplot
plt.figure(figsize=(5, 5))
plt.boxplot(damage.dropna())
plt.title("Boxplot of damage (n = " + str(damage.count()) + ")")
plt.ylabel("Damage (million USD)")
plt.savefig("figures/02_damage_boxplot.png", dpi=150, bbox_inches="tight")
plt.show()


# In[27]:


# 3.5 1.5 x IQR rule
Q1 = damage.quantile(0.25)
Q3 = damage.quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

print("Q1 =", round(Q1, 3), "| Q3 =", round(Q3, 3), "| IQR =", round(IQR, 3))
print("Lower bound =", round(lower_bound, 3), "| upper bound =", round(upper_bound, 3))
print("Outliers below the lower bound:", (damage < lower_bound).sum())
print("Outliers above the upper bound:", (damage > upper_bound).sum())


# In[28]:


# 3.6 sensitivity: results with and without the outliers
without_outliers = df[(df["damage_million_usd"] >= lower_bound) & (df["damage_million_usd"] <= upper_bound)]

sensitivity = pd.DataFrame({
    "Data": ["All rows", "Without outliers"],
    "n": [len(df), len(without_outliers)],
    "Mean": [damage.mean(), without_outliers["damage_million_usd"].mean()],
    "Median": [damage.median(), without_outliers["damage_million_usd"].median()],
    "SD": [damage.std(), without_outliers["damage_million_usd"].std()],
    "Corr wind-damage": [df["wind_kmh"].corr(damage), without_outliers["wind_kmh"].corr(without_outliers["damage_million_usd"])]
})
display(sensitivity.round(3))
sensitivity.round(3).to_csv("outputs/damage_outlier_sensitivity.csv", index=False)


# In[29]:


# 3.7 extreme cases: highest and lowest damage
columns = ["record_id", "date", "region", "category", "wind_kmh", "damage_million_usd", "quality_flag"]
print("10 highest damage values:")
display(df.nlargest(10, "damage_million_usd")[columns])


# In[30]:


print("10 lowest damage values:")
display(df.nsmallest(10, "damage_million_usd")[columns])


# **Findings.** Mean damage is 183.94 and median 186.89 million USD, sample SD 46.83, IQR 65.20 (Q1 = 154.98, Q3 = 220.18), P90 = 248.11. Skewness is -0.64: there is a long tail to the **left** (low damage) and a pile of values at the ceiling of 250.
# 
# **1.5 x IQR rule.** A value is a *possible* outlier if it is below Q1 - 1.5 x IQR = 57.17 or above Q3 + 1.5 x IQR = 317.99. In the data 59 events are below the lower bound and none are above the upper bound (the ceiling at 250 makes high outliers impossible). The rule only marks unusual values, it does not prove that they are errors.
# 
# **Sensitivity.** Without the 59 outliers the mean changes from 183.94 to 185.72, the SD from 46.83 to 44.11 and the correlation between wind and damage from -0.37 to -0.34. The median stays almost the same (186.89 and 187.60). So the mean and the SD depend on how outliers are treated, the median does not, and the conclusions keep the same direction. I keep the outliers in the main analysis because they are real recorded events.
# 
# **Extreme cases.** The highest values are all exactly 250 (the ceiling). Only 6 events have damage 0.1 (the floor), all of them with strong wind (44 to 80 km/h).

# ## 4. Columns 2 and 5: date and wind_kmh

# In[31]:


# 4.1 month column (date is already datetime)
df["month"] = df["date"].dt.to_period("M").astype(str)


# In[32]:


# 4.2 monthly n, median, mean and 95% cluster-bootstrap CI of the mean
monthly_rows = []

for month, group in df.groupby("month"):
    group = group.dropna(subset=["wind_kmh"])
    ci_low, ci_high = cluster_bootstrap_mean_ci(group, "wind_kmh")
    monthly_rows.append({
        "Month": month,
        "n": len(group),
        "Median wind (km/h)": group["wind_kmh"].median(),
        "Mean wind (km/h)": group["wind_kmh"].mean(),
        "95% CI lower": ci_low,
        "95% CI upper": ci_high
    })

monthly_summary = pd.DataFrame(monthly_rows)
monthly_summary.to_csv("outputs/monthly_summary.csv", index=False)
display(monthly_summary.round(2).head(12))


# In[33]:


# 4.3 plot of the monthly mean
month_dates = pd.to_datetime(monthly_summary["Month"])

plt.figure(figsize=(12, 5))
plt.plot(month_dates, monthly_summary["Mean wind (km/h)"], marker="o", markersize=3, label="Monthly mean")
plt.fill_between(month_dates, monthly_summary["95% CI lower"], monthly_summary["95% CI upper"], alpha=0.2, label="95% cluster-bootstrap CI")
plt.title("Monthly mean wind speed, 2020-2025 (n = " + str(monthly_summary["n"].sum()) + ")")
plt.xlabel("Month")
plt.ylabel("Wind speed (km/h)")
plt.legend()
plt.savefig("figures/03_monthly_wind.png", dpi=150, bbox_inches="tight")
plt.show()


# In[34]:


# 4.4 seasonality: calendar months 1-12, all years together
df["calendar_month"] = df["date"].dt.month

season_rows = []
for m, group in df.groupby("calendar_month"):
    ci_low, ci_high = cluster_bootstrap_mean_ci(group, "wind_kmh")
    season_rows.append({"Calendar month": m, "n": len(group), "Mean wind (km/h)": group["wind_kmh"].mean(),
                        "95% CI lower": ci_low, "95% CI upper": ci_high})

seasonality = pd.DataFrame(season_rows)
display(seasonality.round(2))
seasonality.to_csv("outputs/seasonality.csv", index=False)


# In[35]:


# 4.5 seasonality plot
plt.figure(figsize=(7, 5))
plt.errorbar(seasonality["Calendar month"], seasonality["Mean wind (km/h)"],
             yerr=[seasonality["Mean wind (km/h)"] - seasonality["95% CI lower"],
                   seasonality["95% CI upper"] - seasonality["Mean wind (km/h)"]],
             fmt="o-", capsize=3)
plt.title("Mean wind by calendar month (n = " + str(seasonality["n"].sum()) + ")")
plt.xlabel("Calendar month")
plt.ylabel("Wind speed (km/h)")
plt.xticks(range(1, 13))
plt.savefig("figures/04_seasonality.png", dpi=150, bbox_inches="tight")
plt.show()


# In[36]:


# 4.6 trend: change of wind per YEAR (time is in years, not a date string)
df["years"] = (df["date"] - df["date"].min()).dt.days / 365.25

trend_data = df[["site_id", "years", "wind_kmh"]].dropna()
slope = np.polyfit(trend_data["years"], trend_data["wind_kmh"], 1)[0]
print("Trend:", round(slope, 3), "km/h per year (n =", len(trend_data), ")")


# In[37]:


# 4.7 cluster-bootstrap CI of the trend
site_tables = {s: g for s, g in trend_data.groupby("site_id")}
rng = np.random.default_rng(seed)

slopes = []
for i in range(n_boot):
    boot = resample_sites(site_tables, rng)
    slopes.append(np.polyfit(boot["years"], boot["wind_kmh"], 1)[0])

print("95% cluster CI of the trend:", np.percentile(slopes, [2.5, 97.5]).round(3))


# **Findings.** The monthly means of wind are between about 26 and 36 km/h. Every monthly CI is wide (about +-3 to 4 km/h), because a month has only 50 to 90 events from 80 sites.
# 
# *Seasonality:* wind is highest in winter and early spring (January 33.5 km/h) and lowest in summer and early autumn (September 28.3 km/h). The CIs for these two months do not overlap, so the seasonal pattern is clear and has a size of about 5 km/h.
# 
# *Trend:* wind falls slowly by about 0.32 km/h per year (95% cluster CI from -0.59 to -0.07, n = 5,000). The CI does not contain 0, but the change is small compared with the seasonal change.

# ## 5. Association between wind_kmh and damage

# In[38]:


# 5.1 scatterplot wind vs damage
valid = df[["wind_kmh", "damage_million_usd"]].dropna()
slope_line, intercept_line = np.polyfit(valid["wind_kmh"], valid["damage_million_usd"], 1)
x_line = np.linspace(valid["wind_kmh"].min(), valid["wind_kmh"].max(), 50)

plt.figure(figsize=(7, 5))
plt.scatter(valid["wind_kmh"], valid["damage_million_usd"], alpha=0.3, s=10)
plt.plot(x_line, slope_line * x_line + intercept_line, color="red")
plt.title("Wind speed vs damage (n = " + str(len(valid)) + ", synthetic data)")
plt.xlabel("Wind speed (km/h)")
plt.ylabel("Damage (million USD)")
plt.savefig("figures/05_scatter_wind_damage.png", dpi=150, bbox_inches="tight")
plt.show()


# In[39]:


# 5.2 scatterplot vehicles vs damage
valid = df[["vehicles", "damage_million_usd"]].dropna()
slope_line, intercept_line = np.polyfit(valid["vehicles"], valid["damage_million_usd"], 1)
x_line = np.linspace(valid["vehicles"].min(), valid["vehicles"].max(), 50)

plt.figure(figsize=(7, 5))
plt.scatter(valid["vehicles"], valid["damage_million_usd"], alpha=0.3, s=10)
plt.plot(x_line, slope_line * x_line + intercept_line, color="red")
plt.title("Vehicles vs damage (n = " + str(len(valid)) + ", synthetic data)")
plt.xlabel("Number of vehicles")
plt.ylabel("Damage (million USD)")
plt.savefig("figures/06_scatter_vehicles_damage.png", dpi=150, bbox_inches="tight")
plt.show()


# In[40]:


# 5.3 function: cluster-bootstrap CI for Pearson and Spearman correlation
def corr_ci(data, x_col, y_col):
    site_tables = {s: g for s, g in data.groupby("site_id")}
    rng = np.random.default_rng(seed)

    pearson_list = []
    spearman_list = []
    for i in range(n_boot):
        boot = resample_sites(site_tables, rng)
        pearson_list.append(boot[x_col].corr(boot[y_col]))
        spearman_list.append(boot[x_col].corr(boot[y_col], method="spearman"))

    return np.percentile(pearson_list, [2.5, 97.5]), np.percentile(spearman_list, [2.5, 97.5])


# In[41]:


# 5.4 which correlations to calculate
analyses = [
    ("Wind vs damage (overall)", df, "wind_kmh"),
    ("Wind vs damage (Crown)", df[df["category"] == "Crown"], "wind_kmh"),
    ("Wind vs damage (Ground)", df[df["category"] == "Ground"], "wind_kmh"),
    ("Wind vs damage (Mixed)", df[df["category"] == "Mixed"], "wind_kmh"),
    ("Wind vs damage (Surface)", df[df["category"] == "Surface"], "wind_kmh"),
    ("Wind vs damage (without Review rows)", df[~df["is_review"]], "wind_kmh"),
    ("Vehicles vs damage (overall)", df, "vehicles"),
]


# In[42]:


# 5.5 correlations with cluster CI
corr_rows = []

for label, data, x_col in analyses:
    valid = data[[x_col, "damage_million_usd", "site_id"]].dropna()
    pearson_r, pearson_p = stats.pearsonr(valid[x_col], valid["damage_million_usd"])
    spearman_rho, spearman_p = stats.spearmanr(valid[x_col], valid["damage_million_usd"])
    pearson_ci, spearman_ci = corr_ci(valid, x_col, "damage_million_usd")

    corr_rows.append({
        "Analysis": label,
        "n": len(valid),
        "Pearson r": pearson_r,
        "Pearson CI lower": pearson_ci[0],
        "Pearson CI upper": pearson_ci[1],
        "Spearman rho": spearman_rho,
        "Spearman CI lower": spearman_ci[0],
        "Spearman CI upper": spearman_ci[1],
        "Pearson naive p": pearson_p
    })

correlation_results = pd.DataFrame(corr_rows)
correlation_results.to_csv("outputs/correlation_results.csv", index=False)
display(correlation_results.round(3))


# In[43]:


# 5.6 naive CI for the overall Pearson r (Fisher z) - it assumes independent rows
r = correlation_results.loc[0, "Pearson r"]
n = correlation_results.loc[0, "n"]
z = np.arctanh(r)
se = 1 / np.sqrt(n - 3)

print("Naive 95% CI:", round(np.tanh(z - 1.96 * se), 3), "to", round(np.tanh(z + 1.96 * se), 3))
print("Cluster 95% CI:", round(correlation_results.loc[0, "Pearson CI lower"], 3), "to", round(correlation_results.loc[0, "Pearson CI upper"], 3))


# In[44]:


# 5.7 within-site correlation (the mean of each site is removed)
d = df[["site_id", "wind_kmh", "damage_million_usd"]].dropna()
wind_within = d["wind_kmh"] - d.groupby("site_id")["wind_kmh"].transform("mean")
damage_within = d["damage_million_usd"] - d.groupby("site_id")["damage_million_usd"].transform("mean")

print("Within-site Pearson r:", round(wind_within.corr(damage_within), 3), "(n =", len(d), ")")


# In[45]:


# 5.8 how similar are rows of the same site? (ICC and design effect for damage)
site_values = [g["damage_million_usd"].values for s, g in df.groupby("site_id")]
F = stats.f_oneway(*site_values).statistic
k = len(df) / df["site_id"].nunique()

icc = (F - 1) / (F + k - 1)
design_effect = 1 + (k - 1) * icc
print("ICC =", round(icc, 3), "| design effect =", round(design_effect, 1), "| n =", df["damage_million_usd"].count())


# In[46]:


# 5.9 vehicles: what does this variable measure? mean by resource level
display(df.groupby("resource_level")[["vehicles", "firefighters", "damage_million_usd"]].mean().round(2))


# In[47]:


# 5.10 vehicles vs damage inside each resource level
for level, group in df.groupby("resource_level"):
    valid = group[["vehicles", "damage_million_usd"]].dropna()
    print(level, "r =", round(valid["vehicles"].corr(valid["damage_million_usd"]), 3), "n =", len(valid))
print("Vehicles vs wind r =", round(df["vehicles"].corr(df["wind_kmh"]), 3))


# **Direction and size.** The association between wind and damage is **negative and moderate**: Pearson r = -0.37 (95% cluster CI from -0.40 to -0.34) and Spearman rho = -0.32, n = 5,000. Stronger wind goes together with *lower* recorded damage. It is the same in every category (r from -0.34 for Surface to -0.46 for Ground) and without the Review rows (r = -0.38). The direction is the opposite of what we expect for real fires. This is an association in synthetic data and it does not show that wind reduces damage. The ceiling at 250 may also play a role.
# 
# **Is it caused by differences between sites?** No. When the mean of each site is removed, the correlation is even a little stronger (-0.44). The naive CI for r (from -0.39 to -0.35) is a bit narrower than the cluster CI. For damage the ICC is about 0.16 and the design effect about 11, so rows from the same site are similar and the naive intervals are too narrow.
# 
# **Vehicles.** The correlation of vehicles with damage is almost zero (r = 0.047, 95% cluster CI from 0.016 to 0.077, n = 4,939 non-missing). The correlation stays the same inside each resource level (0.047, 0.045 and 0.041), so `resource_level` does not explain it. *Alternative mechanism:* vehicles are a **response** variable. They are sent after the fire starts, so more vehicles are probably sent to bigger events (reverse direction), and the small positive link does not mean that vehicles increase damage. The data cannot test this directly. Separately, sites with `High` resource level use more vehicles than `Low` (86 and 77 on average).
# 
# The naive p-values (they assume independent rows) are not used for decisions; the cluster CIs are the main result.

# ## 6. Hypothesis test: Crown vs Surface
# 
# **H0:** the mean damage of Crown fires is equal to the mean damage of Surface fires (difference = 0).
# **H1 (two-sided):** the two means are different. Significance level alpha = 0.05.
# 
# The main decision is based on the cluster-bootstrap CI of the difference. Welch t-test is shown for comparison (it assumes independent rows).

# In[48]:


# 6.1 two groups
crown = df.loc[df["category"] == "Crown", "damage_million_usd"].dropna()
surface = df.loc[df["category"] == "Surface", "damage_million_usd"].dropna()

n1, n2 = len(crown), len(surface)
mean1, mean2 = crown.mean(), surface.mean()
var1, var2 = crown.var(ddof=1), surface.var(ddof=1)

print("Crown: n =", n1, "mean =", round(mean1, 3))
print("Surface: n =", n2, "mean =", round(mean2, 3))


# In[49]:


# 6.2 Welch t-test, degrees of freedom and effect size
t_stat, p_value = stats.ttest_ind(crown, surface, equal_var=False)

se = np.sqrt(var1 / n1 + var2 / n2)
welch_df = se ** 4 / ((var1 / n1) ** 2 / (n1 - 1) + (var2 / n2) ** 2 / (n2 - 1))

pooled_sd = np.sqrt(((n1 - 1) * var1 + (n2 - 1) * var2) / (n1 + n2 - 2))
cohens_d = (mean1 - mean2) / pooled_sd

print("Difference:", round(mean1 - mean2, 3))
print("Welch t =", round(t_stat, 3), "| df =", round(welch_df, 1), "| p =", round(p_value, 4))
print("Cohen d =", round(cohens_d, 3))


# In[50]:


# 6.3 naive 95% CI of the difference
t_crit = stats.t.ppf(0.975, welch_df)
naive_low = (mean1 - mean2) - t_crit * se
naive_high = (mean1 - mean2) + t_crit * se
print("Naive CI:", round(naive_low, 3), "to", round(naive_high, 3))


# In[51]:


# 6.4 function: cluster-bootstrap CI of the difference between two categories
def cluster_diff_ci(cat1, cat2):
    data = df[df["category"].isin([cat1, cat2])][["site_id", "category", "damage_million_usd"]].dropna()
    site_tables = {s: g for s, g in data.groupby("site_id")}
    rng = np.random.default_rng(seed)

    differences = []
    for i in range(n_boot):
        boot = resample_sites(site_tables, rng)
        mean_a = boot.loc[boot["category"] == cat1, "damage_million_usd"].mean()
        mean_b = boot.loc[boot["category"] == cat2, "damage_million_usd"].mean()
        differences.append(mean_a - mean_b)

    return np.percentile(differences, [2.5, 97.5])


# In[52]:


# 6.5 cluster CI for Crown - Surface (both means come from the same resampled table)
cluster_low, cluster_high = cluster_diff_ci("Crown", "Surface")
print("Cluster CI:", round(cluster_low, 3), "to", round(cluster_high, 3))
print("CI contains 0:", cluster_low <= 0 <= cluster_high)


# In[53]:


# 6.6 main result table
main_result = pd.DataFrame([{
    "Test": "Main: Crown vs Surface",
    "Group 1": "Crown", "Group 2": "Surface",
    "n1": n1, "n2": n2, "Mean 1": mean1, "Mean 2": mean2,
    "Difference": mean1 - mean2, "Welch t": t_stat, "Welch df": welch_df,
    "p naive": p_value, "Cohen d": cohens_d,
    "Cluster CI lower": cluster_low, "Cluster CI upper": cluster_high
}])
display(main_result.round(4))


# In[54]:


# 6.7 additional tests: the other five pairs of categories
pairs = [("Crown", "Ground"), ("Crown", "Mixed"), ("Surface", "Ground"), ("Surface", "Mixed"), ("Ground", "Mixed")]
extra_rows = []

for cat1, cat2 in pairs:
    a = df.loc[df["category"] == cat1, "damage_million_usd"].dropna()
    b = df.loc[df["category"] == cat2, "damage_million_usd"].dropna()
    t, p = stats.ttest_ind(a, b, equal_var=False)
    low, high = cluster_diff_ci(cat1, cat2)

    extra_rows.append({
        "Test": "Additional",
        "Group 1": cat1, "Group 2": cat2,
        "n1": len(a), "n2": len(b), "Mean 1": a.mean(), "Mean 2": b.mean(),
        "Difference": a.mean() - b.mean(), "Welch t": t, "p naive": p,
        "Cluster CI lower": low, "Cluster CI upper": high
    })

extra_results = pd.DataFrame(extra_rows)


# In[55]:


# 6.8 Holm correction for the additional tests
from statsmodels.stats.multitest import multipletests

reject, p_holm, _, _ = multipletests(extra_results["p naive"], alpha=0.05, method="holm")
extra_results["p Holm"] = p_holm
extra_results["Reject H0 after Holm"] = reject
display(extra_results.round(4))


# In[56]:


# 6.9 save all hypothesis results
hypothesis_results = pd.concat([main_result, extra_results], ignore_index=True)
hypothesis_results.to_csv("outputs/hypothesis_results.csv", index=False)


# In[57]:


# 6.10 mean damage by category with cluster CI
cat_rows = []
for category, group in df.groupby("category"):
    ci_low, ci_high = cluster_bootstrap_mean_ci(group, "damage_million_usd")
    cat_rows.append({"Category": category, "n": len(group), "Mean": group["damage_million_usd"].mean(),
                     "CI lower": ci_low, "CI upper": ci_high})

category_means = pd.DataFrame(cat_rows)
display(category_means.round(2))
category_means.to_csv("outputs/category_means.csv", index=False)


# In[58]:


# 6.11 plot
plt.figure(figsize=(6, 5))
plt.errorbar(category_means["Category"], category_means["Mean"],
             yerr=[category_means["Mean"] - category_means["CI lower"], category_means["CI upper"] - category_means["Mean"]],
             fmt="o", capsize=5)
plt.title("Mean damage by category (n = " + str(category_means["n"].sum()) + ", synthetic data)")
plt.xlabel("Fire category")
plt.ylabel("Mean damage (million USD)")
plt.savefig("figures/07_damage_by_category.png", dpi=150, bbox_inches="tight")
plt.show()


# **Main result.** Crown minus Surface = 5.60 million USD (Crown 180.72, n = 1,272; Surface 175.13, n = 1,213). Welch t = 3.04, df = 2,482.9, naive p = 0.0024, Cohen d = 0.12. The 95% cluster CI is from 2.15 to 9.17 and does not contain 0, so **H0 is rejected at alpha = 0.05**. The difference is statistically clear but **small** (d = 0.12, about 3% of the mean).
# 
# **Why naive p-values are limited.** The Welch test treats 5,000 rows as independent, but rows of the same site are similar (ICC about 0.16, design effect about 11). So the real sample size is smaller and a naive p-value is often too small. Here the naive CI (about 2.0 to 9.2) and the cluster CI (2.2 to 9.2) agree, but the cluster CI is the main evidence.
# 
# **Additional tests with Holm.** Mixed fires have the highest mean damage (195.10). After Holm correction all five other differences are also significant, and their cluster CIs do not contain 0 (for example Mixed - Surface = 20.0, Mixed - Crown = 14.4). The weakest result is Crown vs Ground (Crown is 3.9 lower, Holm p = 0.038).

# ## 7. Paired comparison: wind_kmh vs baseline_wind_kmh

# In[59]:


# 7.1 paired data and the change delta = current - baseline
paired = df[["site_id", "date", "baseline_date", "wind_kmh", "baseline_wind_kmh"]].dropna().copy()
paired["delta"] = paired["wind_kmh"] - paired["baseline_wind_kmh"]
print("Pairs (n):", len(paired))


# In[60]:


# 7.2 baseline date: how far is it from the event date?
print("Days between baseline_date and date:", (paired["date"] - paired["baseline_date"]).dt.days.unique())


# In[61]:


# 7.3 mean, median and shares of the change
print("Mean delta:", round(paired["delta"].mean(), 3), "km/h")
print("Median delta:", round(paired["delta"].median(), 3), "km/h")
print("Share positive:", round((paired["delta"] > 0).mean(), 4))
print("Share negative:", round((paired["delta"] < 0).mean(), 4))
print("Share zero:", round((paired["delta"] == 0).mean(), 4))


# In[62]:


# 7.4 cluster-bootstrap CI for the mean change and for the share of positive changes
site_tables = {s: g for s, g in paired.groupby("site_id")}
rng = np.random.default_rng(seed)

mean_list = []
share_list = []
for i in range(n_boot):
    boot = resample_sites(site_tables, rng)
    mean_list.append(boot["delta"].mean())
    share_list.append((boot["delta"] > 0).mean())

mean_ci = np.percentile(mean_list, [2.5, 97.5])
share_ci = np.percentile(share_list, [2.5, 97.5])
print("95% cluster CI of the mean delta:", mean_ci.round(3))
print("95% cluster CI of the share positive:", share_ci.round(3))


# In[63]:


# 7.5 naive tests for comparison (they assume independent rows)
print("Wilcoxon signed-rank p:", round(stats.wilcoxon(paired["delta"]).pvalue, 4))


# In[64]:


# 7.6 histogram of the change
plt.figure(figsize=(7, 5))
plt.hist(paired["delta"], bins=40, edgecolor="black")
plt.axvline(0, color="red")
plt.title("Change in wind vs baseline (n = " + str(len(paired)) + ", synthetic data)")
plt.xlabel("Delta = wind - baseline (km/h)")
plt.ylabel("Number of wildfire events")
plt.savefig("figures/08_paired_change.png", dpi=150, bbox_inches="tight")
plt.show()


# In[65]:


# 7.7 percentage change: rows with baseline = 0 are separated
zero_baseline = paired[paired["baseline_wind_kmh"] == 0]
valid_pct = paired[paired["baseline_wind_kmh"] != 0].copy()
valid_pct["pct_change"] = 100 * valid_pct["delta"] / valid_pct["baseline_wind_kmh"]

print("Rows with baseline = 0:", len(zero_baseline), "| their mean delta:", round(zero_baseline["delta"].mean(), 2), "km/h")
print("Rows with valid percentage change:", len(valid_pct))
print("Median percentage change:", round(valid_pct["pct_change"].median(), 2), "%")


# In[66]:


# 7.8 cluster CI for the median percentage change
site_tables = {s: g for s, g in valid_pct.groupby("site_id")}
rng = np.random.default_rng(seed)

median_list = []
for i in range(n_boot):
    boot = resample_sites(site_tables, rng)
    median_list.append(boot["pct_change"].median())

pct_ci = np.percentile(median_list, [2.5, 97.5])
print("95% cluster CI of the median percentage change:", pct_ci.round(2))


# In[67]:


# 7.9 save paired results
paired_results = pd.DataFrame([{
    "n": len(paired),
    "Mean delta (km/h)": paired["delta"].mean(),
    "CI lower": mean_ci[0],
    "CI upper": mean_ci[1],
    "Median delta (km/h)": paired["delta"].median(),
    "Share positive": (paired["delta"] > 0).mean(),
    "Share positive CI lower": share_ci[0],
    "Share positive CI upper": share_ci[1],
    "Zero baseline rows": len(zero_baseline),
    "Valid percentage n": len(valid_pct),
    "Median percentage change (%)": valid_pct["pct_change"].median(),
    "Percentage CI lower": pct_ci[0],
    "Percentage CI upper": pct_ci[1]
}])
paired_results.to_csv("outputs/paired_wind_results.csv", index=False)


# **Findings** (delta = current - baseline, n = 5,000 pairs). Mean delta = +0.19 km/h with 95% cluster CI from -0.02 to 0.41; median delta = 0. The CI contains 0, so **there is no evidence of a change** (a non-significant result is also a valid result). 49.8% of the changes are positive, 49.6% negative and 0.6% are exactly zero. The naive Wilcoxon test gives the same picture (p = 0.94).
# 
# **Baseline date.** `baseline_date` is exactly 365 days before `date` in every row. So every pair compares the same calendar day one year apart: the season is the same and the time gap is constant, so no more adjustment is needed.
# 
# **Percentage change.** 121 rows have baseline wind = 0, the percentage change is not defined for them, so they are treated separately (their mean delta is +5.06 km/h, which is natural because wind cannot be below 0). For the other 4,879 rows the median percentage change is -0.40% (95% cluster CI from -1.41% to 0.26%).

# ## 8. Regression model

# In[68]:


# 8.1 imports for the model
from sklearn.model_selection import GroupShuffleSplit, GroupKFold, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


# In[69]:


# 8.2 target, predictors and groups
target = "damage_million_usd"
numeric_features = ["wind_kmh", "humidity_pct", "rainfall_mm"]
categorical_features = ["category", "resource_level"]
features = numeric_features + categorical_features

model_data = df[features + [target, "site_id"]].dropna(subset=[target, "site_id"])
X = model_data[features]
y = model_data[target]
site_groups = model_data["site_id"]


# In[70]:


# 8.3 grouped train-test split (whole sites go to train or to test)
splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=42)
train_idx, test_idx = next(splitter.split(X, y, groups=site_groups))

X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

print("Training rows:", len(X_train), "| test rows:", len(X_test))
print("Training sites:", site_groups.iloc[train_idx].nunique(), "| test sites:", site_groups.iloc[test_idx].nunique())
print("Sites in both parts:", len(set(site_groups.iloc[train_idx]) & set(site_groups.iloc[test_idx])))


# In[71]:


# 8.4 preprocessing: imputation and encoding are learned on the training data only
numeric_pipeline = Pipeline([("imputer", SimpleImputer(strategy="median"))])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(drop="first", handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features)
], sparse_threshold=0)


# In[72]:


# 8.5 fit the regression
model = Pipeline([("preprocessor", preprocessor), ("regressor", LinearRegression())])
model.fit(X_train, y_train)


# In[73]:


# 8.6 predictions: regression and the training-mean baseline
pred_train = model.predict(X_train)
pred_test = model.predict(X_test)
baseline_train = np.full(len(y_train), y_train.mean())
baseline_test = np.full(len(y_test), y_train.mean())


# In[74]:


# 8.7 MAE, RMSE and R2
compare = [
    ("Training mean baseline", "train", y_train, baseline_train),
    ("Training mean baseline", "test", y_test, baseline_test),
    ("Multiple regression", "train", y_train, pred_train),
    ("Multiple regression", "test", y_test, pred_test),
]

metric_rows = []
for name, part, y_true, y_pred in compare:
    metric_rows.append({
        "Model": name, "Data": part, "n": len(y_true),
        "MAE": mean_absolute_error(y_true, y_pred),
        "RMSE": np.sqrt(mean_squared_error(y_true, y_pred)),
        "R2": r2_score(y_true, y_pred)
    })

model_metrics = pd.DataFrame(metric_rows)
model_metrics.to_csv("outputs/model_metrics.csv", index=False)
display(model_metrics.round(4))


# In[75]:


# 8.8 stability check: grouped 5-fold cross-validation
cv_scores = cross_val_score(model, X, y, groups=site_groups, cv=GroupKFold(n_splits=5), scoring="r2")
print("R2 in 5 folds:", cv_scores.round(3), "| mean:", round(cv_scores.mean(), 3))


# In[76]:


# 8.9 residual plots (test data)
residuals = y_test - pred_test

plt.figure(figsize=(7, 5))
plt.scatter(pred_test, residuals, alpha=0.4, s=10)
plt.axhline(0, color="red", linestyle="--")
plt.title("Residuals vs predicted (test n = " + str(len(y_test)) + ")")
plt.xlabel("Predicted damage (million USD)")
plt.ylabel("Residual (million USD)")
plt.savefig("figures/09_residuals.png", dpi=150, bbox_inches="tight")
plt.show()


# In[77]:


plt.figure(figsize=(7, 5))
plt.hist(residuals, bins=30, edgecolor="black")
plt.title("Distribution of test residuals (n = " + str(len(y_test)) + ")")
plt.xlabel("Residual (million USD)")
plt.ylabel("Number of events")
plt.savefig("figures/10_residual_histogram.png", dpi=150, bbox_inches="tight")
plt.show()


# In[78]:


# 8.10 Breusch-Pagan test for heteroscedasticity (on the training data)
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan

X_train_t = model.named_steps["preprocessor"].transform(X_train)
ols = sm.OLS(y_train.values, sm.add_constant(X_train_t)).fit()

bp_stat, bp_p, f_stat, f_p = het_breuschpagan(ols.resid, ols.model.exog)
print("Breusch-Pagan statistic =", round(bp_stat, 2), "| p-value =", bp_p)


# In[79]:


# 8.11 residual spread for low and high predictions (test data)
pred_series = pd.Series(pred_test, index=y_test.index)
pred_group = pd.qcut(pred_series, 4, labels=["lowest", "2", "3", "highest"])
print(residuals.groupby(pred_group, observed=True).std().round(2))
print("Test predictions above 250:", (pred_test > 250).sum())


# In[80]:


# 8.12 coefficients with cluster-robust CI (training data, clustered by site)
site_codes = pd.factorize(site_groups.iloc[train_idx])[0]
ols_cluster = sm.OLS(y_train.values, sm.add_constant(X_train_t)).fit(cov_type="cluster", cov_kwds={"groups": site_codes})

names = ["const"] + list(model.named_steps["preprocessor"].get_feature_names_out())
coef_table = pd.DataFrame({
    "Variable": names,
    "Coefficient": ols_cluster.params,
    "CI lower": ols_cluster.conf_int()[:, 0],
    "CI upper": ols_cluster.conf_int()[:, 1]
})
coef_table.to_csv("outputs/regression_coefficients.csv", index=False)
display(coef_table.round(3))


# **Setup.** Target: damage. Predictors: wind, humidity, rainfall, category and resource level. Split: `GroupShuffleSplit` by `site_id`, 80/20, `random_state = 42`. 64 sites (4,048 rows) are used for training, 16 sites (952 rows) for testing, and no site is in both parts.
# 
# **Results on the test data (million USD).** The training-mean baseline has MAE 37.97, RMSE 47.06 and R2 = -0.005. The multiple regression has MAE 34.67, RMSE 42.25 and R2 = 0.190. So the regression is better than the baseline, but it explains only about 19% of the variation. R2 on the training data (0.215) and the grouped cross-validation (mean 0.185) are close to the test value, so there is no strong overfitting.
# 
# **Coefficients** (reference groups: Crown and High resource level; all are associations, not causes): wind -1.30 per km/h, humidity -0.22 per %, rainfall +0.25 per mm; Mixed +22.7, Ground +10.2, Surface -6.6; Low resource level -13.6 and Medium -4.6.
# 
# **Residuals and heteroscedasticity.** The Breusch-Pagan test is highly significant (p is about 2e-22), so the variance of the errors is **not constant**: the residual SD is about 51 for the lowest predictions and about 36 for the highest ones. This fits the ceiling at 250, which squeezes the spread of high damage. So the usual standard errors are not reliable (I used cluster-robust ones) and the prediction error is not the same for all events.
# 
# **Data leakage check.** (1) Whole sites are split, so rows of one site are never in both train and test. (2) Imputation and one-hot encoding are fitted on the training rows only (they are inside the pipeline). (3) Variables known only after the fire (area, houses damaged, evacuated people, containment hours, water used, firefighters, vehicles) and the baseline columns are not predictors. (4) The test data were used only for the final metrics.

# ## 9. Individual extension: wind-speed quartiles

# In[81]:


# 9.1 four wind groups
df["wind_group"], edges = pd.qcut(df["wind_kmh"], q=4, labels=["Q1 (Lowest)", "Q2", "Q3", "Q4 (Highest)"], retbins=True)
print("Quartile edges (km/h):", edges.round(2))


# In[82]:


# 9.2 damage statistics in each group
wind_group_summary = df.groupby("wind_group", observed=True)["damage_million_usd"].agg(
    n="count", mean="mean", median="median", std="std",
    Q1=lambda s: s.quantile(0.25), Q3=lambda s: s.quantile(0.75)
)
wind_group_summary["IQR"] = wind_group_summary["Q3"] - wind_group_summary["Q1"]
display(wind_group_summary.round(2))


# In[83]:


# 9.3 boxplot
plt.figure(figsize=(8, 5))
sns.boxplot(data=df, x="wind_group", y="damage_million_usd")
plt.title("Damage by wind-speed quartile (n = " + str(df["damage_million_usd"].count()) + ", synthetic data)")
plt.xlabel("Wind-speed quartile")
plt.ylabel("Damage (million USD)")
plt.savefig("figures/11_damage_by_wind_quartile.png", dpi=150, bbox_inches="tight")
plt.show()


# In[84]:


# 9.4 cluster bootstrap: group means, difference Q4 - Q1 and ratio of SDs
quart_data = df[["site_id", "wind_group", "damage_million_usd"]].dropna()
site_tables = {s: g for s, g in quart_data.groupby("site_id")}
rng = np.random.default_rng(seed)

mean_list = []
diff_list = []
ratio_list = []
for i in range(n_boot):
    boot = resample_sites(site_tables, rng)
    means = boot.groupby("wind_group", observed=True)["damage_million_usd"].mean()
    sds = boot.groupby("wind_group", observed=True)["damage_million_usd"].std()
    mean_list.append(means.values)
    diff_list.append(means.iloc[3] - means.iloc[0])
    ratio_list.append(sds.iloc[3] / sds.iloc[0])


# In[85]:


# 9.5 results with uncertainty
mean_ci = np.percentile(mean_list, [2.5, 97.5], axis=0)
diff_ci = np.percentile(diff_list, [2.5, 97.5])
ratio_ci = np.percentile(ratio_list, [2.5, 97.5])

wind_group_ci = pd.DataFrame({
    "wind_group": wind_group_summary.index,
    "n": wind_group_summary["n"].values,
    "mean_damage": wind_group_summary["mean"].values,
    "CI_lower": mean_ci[0],
    "CI_upper": mean_ci[1]
})
wind_group_ci.to_csv("outputs/wind_quartile_damage_cluster_CI.csv", index=False)
display(wind_group_ci.round(2))

q1_mean = wind_group_summary["mean"].iloc[0]
q4_mean = wind_group_summary["mean"].iloc[3]
print("Q4 - Q1 =", round(q4_mean - q1_mean, 2), "million USD, 95% cluster CI:", diff_ci.round(2))
print("Difference as share of the Q1 mean:", round((q4_mean - q1_mean) / q1_mean * 100, 1), "%")
print("SD(Q4) / SD(Q1) =", round(wind_group_summary["std"].iloc[3] / wind_group_summary["std"].iloc[0], 2), ", 95% cluster CI:", ratio_ci.round(2))


# In[86]:


# 9.6 naive Kruskal-Wallis test for all four groups
groups_list = [g["damage_million_usd"].dropna() for name, g in df.groupby("wind_group", observed=True)]
print("Kruskal-Wallis p-value:", stats.kruskal(*groups_list).pvalue)
wind_group_summary.to_csv("outputs/wind_quartile_damage_summary.csv")


# In[87]:


# 9.7 do the Review rows change the main results? (point estimates only)
df_no_review = df[~df["is_review"]]

for name, data in [("All rows", df), ("Without Review rows", df_no_review)]:
    crown_mean = data.loc[data["category"] == "Crown", "damage_million_usd"].mean()
    surface_mean = data.loc[data["category"] == "Surface", "damage_million_usd"].mean()
    group_means = data.groupby("wind_group", observed=True)["damage_million_usd"].mean()
    print(name, "| r(wind, damage) =", round(data["wind_kmh"].corr(data["damage_million_usd"]), 3),
          "| Crown - Surface =", round(crown_mean - surface_mean, 2),
          "| Q4 - Q1 =", round(group_means.iloc[3] - group_means.iloc[0], 2))


# **Conclusion 1 - damage is lower when wind is stronger.** Mean damage is 197.98 million USD in the lowest wind quartile (Q1, wind up to 19.3 km/h, 95% CI from 193.72 to 202.20) and 156.24 in the highest quartile (Q4, wind above 41.1 km/h, CI from 150.48 to 161.78). The difference Q4 - Q1 is -41.7 million USD (95% cluster CI from -45.5 to -38.1), about 21% of the Q1 mean. Q1 and Q2 are almost the same, the decrease starts in Q3.
# 
# **Conclusion 2 - damage is less predictable in strong wind.** The SD is 52.5 in Q4 and 38.1 in Q1, a ratio of 1.38 (95% cluster CI from 1.31 to 1.45); the IQR grows from 59.4 to 72.0. The strongest-wind fires include both the smallest damages (down to 0.1) and very high ones, so wind alone is a poor guide in the top quartile.
# 
# These are associations in synthetic data and do not prove causation. Without the 25 Review rows the main numbers change very little, so the results are not caused by them.
# 
# **Recommendation 1 - plan resources by fire category, Mixed fires first.** Mixed fires have the highest mean damage (195.1 million USD): 14.4 higher than Crown and 20.0 higher than Surface (cluster CIs do not contain 0 and the differences stay significant after Holm). The Crown-Surface difference (5.6, d = 0.12) is too small for a separate priority rule.
# 
# **Recommendation 2 - improve data collection before using the data for decisions.** (a) 9.3% of the events have damage exactly 250, so the true damage of the biggest fires is unknown; the ceiling should be removed or raised. (b) Manual collection loses about twice as much data as the other modes (11.6% of rows with a gap against 4.4 to 5.3%), so manual forms should be standardised. Until then wind speed should not be used as a simple damage indicator (R2 = 0.19 and strong heteroscedasticity).

# ## 10. Reproducibility: formulas with real values and functions

# In[88]:


# 10.1 mean: x_bar = sum(x) / n
x = df["damage_million_usd"].dropna().to_numpy()
n = len(x)

xbar = np.sum(x) / n
print("sum(x) =", round(np.sum(x), 3), "| n =", n)
print("mean =", round(xbar, 4), "| pandas mean =", round(df["damage_million_usd"].mean(), 4))


# In[89]:


# 10.2 sample variance: s2 = sum((x - x_bar)^2) / (n - 1)
sum_sq = np.sum((x - xbar) ** 2)
s2 = sum_sq / (n - 1)
print("sum of squares =", round(sum_sq, 3), "| n - 1 =", n - 1)
print("variance =", round(s2, 3), "| pandas variance =", round(df["damage_million_usd"].var(), 3))


# In[90]:


# 10.3 naive 95% CI of the mean: x_bar +- t * s / sqrt(n)
se_mean = np.sqrt(s2) / np.sqrt(n)
t_star = stats.t.ppf(0.975, n - 1)
ci_manual = (xbar - t_star * se_mean, xbar + t_star * se_mean)
ci_scipy = stats.t.interval(0.95, n - 1, loc=xbar, scale=stats.sem(x))

print("SE =", round(se_mean, 4), "| t* =", round(t_star, 4))
print("Manual CI:", np.round(ci_manual, 3), "| scipy CI:", np.round(ci_scipy, 3))


# In[91]:


# 10.4 cluster-bootstrap CI of the same mean (it is wider because rows of one site are similar)
print("Cluster CI:", cluster_bootstrap_mean_ci(df, "damage_million_usd").round(3))


# In[92]:


# 10.5 Welch t = (mean1 - mean2) / sqrt(s1^2/n1 + s2^2/n2)
se_welch = np.sqrt(var1 / n1 + var2 / n2)
t_manual = (mean1 - mean2) / se_welch
print("difference =", round(mean1 - mean2, 4), "| SE =", round(se_welch, 4))
print("t manual =", round(t_manual, 4), "| t scipy =", round(t_stat, 4))


# In[93]:


# 10.6 RMSE = sqrt(sum((y - y_hat)^2) / n) on the test data
rmse_manual = np.sqrt(np.sum((y_test - pred_test) ** 2) / len(y_test))
print("RMSE manual =", round(rmse_manual, 4), "| sklearn =", round(np.sqrt(mean_squared_error(y_test, pred_test)), 4))


# In[94]:


# 10.7 do the manual results agree with the libraries?
print("mean:", np.isclose(xbar, df["damage_million_usd"].mean()))
print("variance:", np.isclose(s2, df["damage_million_usd"].var()))
print("CI:", np.allclose(ci_manual, ci_scipy))
print("Welch t:", np.isclose(t_manual, t_stat))
print("RMSE:", np.isclose(rmse_manual, np.sqrt(mean_squared_error(y_test, pred_test))))


# In[95]:


# 10.8 functions: load, validate, clean, summarize, plot
def load_data(path):
    return pd.read_csv(path)


def validate_data(data):
    report = {
        "rows": len(data),
        "columns": data.shape[1],
        "duplicate rows": data.duplicated().sum(),
        "duplicate record_id": data["record_id"].duplicated().sum(),
        "missing cells": data.isna().sum().sum()
    }
    return pd.Series(report)


# In[96]:


def clean_data(data):
    cleaned = data.copy()
    cleaned["date"] = pd.to_datetime(cleaned["date"])
    cleaned["baseline_date"] = pd.to_datetime(cleaned["baseline_date"])
    cleaned["is_review"] = cleaned["quality_flag"] == "Review"
    return cleaned


def summarize_damage(data):
    d = data["damage_million_usd"]
    return pd.Series({"n": d.count(), "mean": d.mean(), "median": d.median(), "sd": d.std(),
                      "Q1": d.quantile(0.25), "Q3": d.quantile(0.75), "P90": d.quantile(0.9), "skewness": d.skew()})


def plot_damage(data):
    plt.figure(figsize=(6, 4))
    plt.hist(data["damage_million_usd"].dropna(), bins=30, edgecolor="black")
    plt.xlabel("Damage (million USD)")
    plt.ylabel("Number of wildfire events")
    plt.title("Damage histogram (synthetic data)")
    plt.show()


# In[97]:


# 10.9 run all functions
data_check = load_data(data_file)
display(validate_data(data_check))
cleaned_check = clean_data(data_check)
display(summarize_damage(cleaned_check).round(3))
plot_damage(cleaned_check)


# **Terminal run in VS Code:** the same code is saved as `analysis.py`. Put `03_wildfires.csv` in the folder `data`, run `pip install -r requirements.txt` and then `python analysis.py` in the VS Code terminal. The files are created in the folders `outputs` and `figures`. The output of one terminal run is saved in `terminal_run_log.txt`.
# 
# **Limitations.** (1) All data are synthetic. (2) Several variables are cut at fixed limits, mainly damage at 250 (9.3% of events). (3) There are only 80 sites, so cluster CIs are approximate. (4) The data are observational, so there are no causal conclusions. (5) The linear model explains only about 19% of the variation and the errors are heteroscedastic. (6) Missing values depend on `collection_mode`; the analyses use non-missing rows only.

# ## 11. Excel workbook (Raw Data, Clean Data, Analysis, Dashboard)

# In[98]:


writer = pd.ExcelWriter("outputs/wildfire_analysis.xlsx", engine="openpyxl")
df_raw.to_excel(writer, sheet_name="Raw Data", index=False)
pd.read_csv("outputs/cleaned.csv").to_excel(writer, sheet_name="Clean Data", index=False)


# In[99]:


analysis_tables = [
    ("row_counts.csv", "Row counts before and after cleaning", "Counts of rows, columns and missing cells"),
    ("missing_by_collection_mode.csv", "Missing values by collection_mode", "Share of missing values in %, per column"),
    ("filter_info.csv", "Filter used in the third csv file", "Wind threshold in km/h; n = number of rows"),
    ("summary.csv", "Column 12 damage_million_usd: descriptive statistics", "n = non-missing events; units are given in the column Unit"),
    ("damage_outlier_sensitivity.csv", "Damage: sensitivity to outliers (1.5 x IQR rule)", "Mean, median, SD in million USD; n = events; correlation has no unit"),
    ("monthly_summary.csv", "Monthly wind speed", "Wind in km/h; n = events in the month; CI = 95% cluster bootstrap"),
    ("seasonality.csv", "Mean wind by calendar month", "Wind in km/h; n = events; CI = 95% cluster bootstrap"),
    ("correlation_results.csv", "Correlations with damage", "n = non-missing pairs; r and rho have no unit; CI = 95% cluster bootstrap"),
    ("category_means.csv", "Mean damage by fire category", "Damage in million USD; n = events; CI = 95% cluster bootstrap"),
    ("hypothesis_results.csv", "Hypothesis tests on damage", "n1, n2 = events per group; differences in million USD; Cohen d has no unit"),
    ("paired_wind_results.csv", "Paired comparison: wind vs baseline wind", "n = pairs; changes in km/h; shares are fractions from 0 to 1"),
    ("model_metrics.csv", "Model metrics", "MAE and RMSE in million USD; R2 has no unit; n = rows"),
    ("regression_coefficients.csv", "Regression coefficients (training data)", "Million USD of damage per unit of the variable; n = 4048 training rows; CI cluster-robust"),
    ("wind_quartile_damage_summary.csv", "Damage by wind-speed quartile", "Damage in million USD; n = events in the quartile"),
    ("wind_quartile_damage_cluster_CI.csv", "Mean damage by wind-speed quartile with CI", "Damage in million USD; n = events; CI = 95% cluster bootstrap"),
]

row = 0
for file_name, title, note in analysis_tables:
    table = pd.read_csv("outputs/" + file_name).round(4)
    pd.DataFrame({title: [note]}).to_excel(writer, sheet_name="Analysis", startrow=row, index=False)
    table.to_excel(writer, sheet_name="Analysis", startrow=row + 3, index=False)
    row = row + len(table) + 6


# In[100]:


test_row = model_metrics[(model_metrics["Model"] == "Multiple regression") & (model_metrics["Data"] == "test")].iloc[0]

indicators = pd.DataFrame({
    "Indicator": ["Wildfire events", "Mean damage", "Median damage", "Pearson r, wind vs damage",
                  "Crown - Surface, mean damage", "Cluster 95% CI of Crown - Surface",
                  "Mean paired wind change", "Cluster 95% CI of paired change", "Regression test R2", "Regression test RMSE"],
    "Value": [len(df), round(damage.mean(), 2), round(damage.median(), 2),
              round(correlation_results.loc[0, "Pearson r"], 3), round(mean1 - mean2, 2),
              str(round(cluster_low, 2)) + " to " + str(round(cluster_high, 2)),
              round(paired["delta"].mean(), 3),
              str(round(paired_results.loc[0, "CI lower"], 3)) + " to " + str(round(paired_results.loc[0, "CI upper"], 3)),
              round(test_row["R2"], 3), round(test_row["RMSE"], 2)],
    "Unit / n": ["n = 5000", "million USD", "million USD", "no unit, n = 5000", "million USD, n = 2485",
                 "million USD", "km/h, n = 5000", "km/h", "no unit, n = 952 test rows", "million USD, n = 952 test rows"]
})
indicators.to_excel(writer, sheet_name="Dashboard", index=False)

sheet = writer.sheets["Dashboard"]
sheet.column_dimensions["A"].width = 36
sheet.column_dimensions["B"].width = 22
sheet.column_dimensions["C"].width = 34
sheet["A13"] = "All data are synthetic. Charts use the data table in columns AA-AJ; values are the same as in the Analysis sheet."


# In[101]:


damage_counts, damage_edges = np.histogram(damage.dropna(), bins=20)
delta_counts, delta_edges = np.histogram(paired["delta"], bins=20)
model_test = model_metrics[model_metrics["Data"] == "test"][["Model", "MAE", "RMSE"]]

chart_tables = {
    "damage_hist": pd.DataFrame({"Damage bin start (million USD)": damage_edges[:-1].round(1), "Events": damage_counts}),
    "monthly": monthly_summary[["Month", "Mean wind (km/h)", "95% CI lower", "95% CI upper"]],
    "season": seasonality[["Calendar month", "Mean wind (km/h)", "95% CI lower", "95% CI upper"]],
    "category": category_means[["Category", "Mean", "CI lower", "CI upper"]],
    "quartile": wind_group_ci[["wind_group", "mean_damage", "CI_lower", "CI_upper"]],
    "paired_hist": pd.DataFrame({"Wind change bin start (km/h)": delta_edges[:-1].round(1), "Events": delta_counts}),
    "model": model_test,
}

positions = {}
row = 1
for name, table in chart_tables.items():
    table.round(3).to_excel(writer, sheet_name="Dashboard", startrow=row, startcol=26, index=False)
    positions[name] = (row + 1, row + 1 + len(table))
    row = row + len(table) + 4


# In[102]:


from openpyxl.chart import BarChart, LineChart, Reference

def add_chart(kind, name, title, x_title, y_title, data_cols, anchor):
    first_row, last_row = positions[name]
    chart = LineChart() if kind == "line" else BarChart()
    chart.title = title
    chart.x_axis.title = x_title
    chart.y_axis.title = y_title
    chart.x_axis.delete = False
    chart.y_axis.delete = False
    for col in data_cols:
        chart.add_data(Reference(sheet, min_col=col, min_row=first_row, max_row=last_row), titles_from_data=True)
    chart.set_categories(Reference(sheet, min_col=27, min_row=first_row + 1, max_row=last_row))
    chart.width = 16
    chart.height = 8
    sheet.add_chart(chart, anchor)


# In[103]:


add_chart("bar", "damage_hist", "Damage distribution (n = 5000, synthetic data)",
          "Damage (million USD)", "Number of events", [28], "D2")
add_chart("line", "monthly", "Monthly mean wind with 95% cluster CI (n = 5000)",
          "Month", "Wind speed (km/h)", [28, 29, 30], "N2")
add_chart("line", "season", "Mean wind by calendar month (n = 5000)",
          "Calendar month", "Wind speed (km/h)", [28, 29, 30], "D19")
add_chart("bar", "category", "Mean damage by fire category (n = 5000)",
          "Fire category", "Mean damage (million USD)", [28], "N19")


# In[104]:


add_chart("bar", "quartile", "Mean damage by wind-speed quartile (n = 5000)",
          "Wind-speed quartile", "Mean damage (million USD)", [28], "D36")
add_chart("bar", "paired_hist", "Wind change vs baseline (n = 5000)",
          "Delta = wind - baseline (km/h)", "Number of events", [28], "N36")
add_chart("bar", "model", "Test errors: baseline vs regression (n = 952)",
          "Model", "Error (million USD)", [28, 29], "D53")


# In[105]:


writer.close()
print("Workbook saved: outputs/wildfire_analysis.xlsx")


# In[106]:


for folder in ["outputs", "figures"]:
    print(folder + ":")
    for file_name in sorted(os.listdir(folder)):
        print("   ", file_name)

